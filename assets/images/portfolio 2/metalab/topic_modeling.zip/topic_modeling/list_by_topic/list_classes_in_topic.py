import psycopg2
from gensim.models.ldamodel import LdaModel

#Start database connection
conn = psycopg2.connect(host="localhost",database="curricle_warehouse")
cur = conn.cursor()

#Load lda model
lda = LdaModel.load('ldamodel_course_descripts')

for topic_id in range(50):
	print topic_id
	cur.execute('''select course_title_long from classes where course_id in
		(select course_id from topics where topic_id=%i)''' % topic_id)
	class_names = [x[0] for x in cur.fetchall()]
	print class_names
	#Make our neat little text file
	with open('topic_dump/Topic' + str(topic_id) + '.txt', 'wb') as f:
		f.write(lda.print_topic(topic_id)) #write the topic definition at the top
		f.write('\n\n') #add a couple spaces
		f.write('\n'.join(class_names)) #write in the rest
		f.close()

cur.close()
conn.close()
