import psycopg2
from HTMLParser import HTMLParser
from gensim.models.ldamodel import LdaModel
from gensim import corpora
import nltk

class MLStripper(HTMLParser):
    def __init__(self):
        self.reset()
        self.fed = []
    def handle_data(self, d):
        self.fed.append(d)
    def get_data(self):
        return ''.join(self.fed)

def strip_tags(html):
    s = MLStripper()
    s.feed(html)
    return s.get_data()

lda = LdaModel.load('ldamodel_course_descripts')
stoplist = set(nltk.corpus.stopwords.words('english'))
dictionary = corpora.Dictionary.load_from_text('descriptions_dictionary.txt')

def doc2bow(document):
	document = document.lower().split()
	document = [''.join([i for i in word if i.isalpha()]) for word in document]
	document = [word for word in document if not word in stoplist and not word=='']
	return dictionary.doc2bow(document)


conn = psycopg2.connect(host="localhost",database="curricle_warehouse")
cur = conn.cursor()
cur.execute('select course_id,course_descrlong from classes')
courses = cur.fetchall()

topic_table = []
for i, course in enumerate(courses):
	print i
	descr = course[1]
	try:
		descr = strip_tags(descr)
	except: #workaround for strange Unicode error
		descr = ''
	if not descr.replace(' ','') == '' and not len(descr.split()) <= 10:
		topics = lda.get_document_topics(doc2bow(descr), minimum_probability=.1)
		if not len(topics)==0:
			topic_id = max(topics, key=lambda x:x[1])[0]
			topic_table.append((course[0],topic_id))

cur.executemany('insert into topics values(%s, %s)', topic_table)
conn.commit()
cur.close()
conn.close()


