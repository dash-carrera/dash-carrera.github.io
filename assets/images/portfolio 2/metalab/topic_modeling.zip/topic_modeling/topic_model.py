from gensim import corpora
from gensim.models.ldamodel import LdaModel

dictionary = corpora.Dictionary.load_from_text('descriptions_dictionary.txt')
corpus = corpora.MmCorpus('descripts_corpus.mm')
lda = LdaModel(corpus, num_topics=50, id2word=dictionary)
lda.save('ldamodel_course_descripts')
lda.print_topics(num_topics=50)