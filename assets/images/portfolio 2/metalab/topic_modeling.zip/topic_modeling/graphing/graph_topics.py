from gensim.models.ldamodel import LdaModel
import plotly
plotly.offline.init_notebook_mode()
import plotly.offline as py
import plotly.graph_objs as go
from plotly import tools


lda = LdaModel.load('ldamodel_course_descripts')

topics = lda.show_topics(num_topics=50, num_words=8, formatted=False)
topics2 = topics[25:]
topics = topics[:25]

fig = {}
fig['layout'] = {'title': 'Topic Modeling of Harvard Course Descriptions', 'showlegend': False}
fig['data'] = range(len(topics))

for i, topic in enumerate(topics):
	chart = {}
	chart['name'] = 'Topic ' + str(topic[0])
	chart['labels'] = [word_prob[0] for word_prob in topic[1]]
	chart['values'] = [word_prob[1] for word_prob in topic[1]]
	chart['domain'] = {'x': [.2*(i%5), .2*(i%5+1)], 'y': [.2*(i/5),.2*(i/5+1) ]}
	print 'x', chart['domain']['x'], 'y', chart['domain']['y']
	#Defaults
	chart['type'] = 'pie'
	chart['hoverinfo'] = 'label+percent'
	chart['textinfo'] = 'label'
	# chart['textfont'] = {'size': 20}
	chart['marker'] = {'colors': ['rgb(244,107,134)',
                                  'rgb(255,156,89)',
                                  'rgb(249,251,33)',
                                  'rgb(99,255,110)',
                                  'rgb(28,189,236)',
                                  'rgb(244,107,134)',
                                  'rgb(255,156,89)',
                                  'rgb(249,251,33)',
                                  'rgb(99,255,110)',
                                  'rgb(28,189,236)']
                                  }
	fig['data'][i] = chart
	



py.plot(fig, filename='pie_chart_subplots.html')

#####PLOT 2

fig = {}
fig['layout'] = {'title': 'Topic Modeling of Harvard Course Descriptions 2', 'showlegend': False}
fig['data'] = range(len(topics2))

for i, topic in enumerate(topics2):
	chart = {}
	chart['name'] = 'Topic ' + str(topic[0])
	chart['labels'] = [word_prob[0] for word_prob in topic[1]]
	chart['values'] = [word_prob[1] for word_prob in topic[1]]
	chart['domain'] = {'x': [.2*(i%5), .2*(i%5+1)], 'y': [.2*(i/5),.2*(i/5+1) ]}
	print 'x', chart['domain']['x'], 'y', chart['domain']['y']
	#Defaults
	chart['type'] = 'pie'
	chart['hoverinfo'] = 'label+percent'
	chart['textinfo'] = 'label'
	# chart['textfont'] = {'size': 20}
	chart['marker'] = {'colors': ['rgb(244,107,134)',
                                  'rgb(255,156,89)',
                                  'rgb(249,251,33)',
                                  'rgb(99,255,110)',
                                  'rgb(28,189,236)',
                                  'rgb(244,107,134)',
                                  'rgb(255,156,89)',
                                  'rgb(249,251,33)',
                                  'rgb(99,255,110)',
                                  'rgb(28,189,236)']
                                  }
	fig['data'][i] = chart

py.plot(fig, filename='pie_chart_subplots2.html')