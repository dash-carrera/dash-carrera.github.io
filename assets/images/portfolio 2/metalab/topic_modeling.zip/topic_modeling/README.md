# Topic modeling

Ok, lots to cover in here.

This is some topic modeling performed on the course descriptions found in the data dump from Student Information Services. It uses Latent Dirilecht Allocation, as implemented in Gensim (https://radimrehurek.com/gensim/models/ldamodel.html).

The goal here was to use topic modeling across departments and throughout Harvard's history to find a sort of "missing department" — some new way of thinking about the data that breaks free of the usual beauracratic distinctions.

## Dependencies
* Gensim
* Natural Language Toolkit
* Plotly

## Files

#### Convert_to_Corpora
This script will convert the list of course descriptions into a format Gensim can use. In addition, stopwords and non-alphabetic characters are removed at this stage, and the descriptions are prepared for a bag of words interpretation.

#### Topic_model

This performs the topic modeling! It should take about 5-10 minutes for the topic modeling to finish.

## Folders

#### list_by_topic
This was done after the topic modeling. It lists all the classes by the topics found.
It's written in a bit of a strange way — before I did this, I realized that I should have just stuck all the data into a SQL server since that's where it came from in the first place. So, this utilizes the SQL imported data, but has to redo some of the data massaging that was done at earlier steps in order to make the data usable. At the same time, it has to import the LDA model from before. A little weird.

#### Dictionary
This contains the dictionary used in the gensim process.

#### blank_and_short_descrips
One of the things needed to be done in massaging the data is removing blank descriptions and descriptions that are 10 words or less. These are complete lists of the titles of those courses.

#### ldamodel
All the strange components of the LDAModel that is created are in this folder. This is the result of the topic modeling.

#### parsing 
This has the SQL script for importing data to the SQL database, the script for manually parsing the ods_classes dump, and a pickle dump and text dump of the parsed out descriptions
#### graphing
This has some scripts used for graphing the results with Plotly, and the resulting graphs. 
