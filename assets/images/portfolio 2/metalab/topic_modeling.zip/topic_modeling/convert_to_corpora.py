#We need to convert the list into vectors for Gensim
from gensim import corpora
from cPickle import load
import nltk

course_descriptions = load(open('course_descriptions','rb'))

print 'Load complete'

stoplist = set(nltk.corpus.stopwords.words('english'))
course_descriptions = [[word for word in document.lower().split()] for document in course_descriptions]

print 'Tokenized document'

course_descriptions = [[''.join([i for i in word if i.isalpha()]) for word in document] for document in course_descriptions]

print 'Non alphabetic characters removed'

course_descriptions = [[word for word in document if not word in stoplist] for document in course_descriptions]

print 'Stopwods removed'

course_descriptions = [[word for word in document if not word == ''] for document in course_descriptions]

print 'Blanks removed'
print 'Now transferring to dictionary'

dictionary = corpora.Dictionary(course_descriptions)
dictionary.save_as_text('descriptions_dictionary.txt')
corpus = [dictionary.doc2bow(text) for text in course_descriptions]
corpora.MmCorpus.serialize('descripts_corpus.mm', corpus)
