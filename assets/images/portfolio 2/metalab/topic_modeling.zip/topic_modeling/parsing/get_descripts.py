#Are there any cases where the title is not surrounded by paragraph tags?
#Yes

#Need to parse by not just commas

#Can I parse by ,"?
#No, because there are some instances of ,, because not everything in
#here is a string

#So if , followed by " look for next "

from HTMLParser import HTMLParser

class MLStripper(HTMLParser):
    def __init__(self):
        self.reset()
        self.fed = []
    def handle_data(self, d):
        self.fed.append(d)
    def get_data(self):
        return ''.join(self.fed)

def strip_tags(html):
    s = MLStripper()
    s.feed(html)
    return s.get_data()

##### Start of my code

from cPickle import dump

classes_csv = open('ods_classes_view.csv','rb')
classes_csv.readline() #Skip headers
string = classes_csv.read()

stop_after = 1000
list_of_entries = []

course_descriptions = []
short_descriptions = [] #Descriptions with less than ten words
blank_descriptions = [] #Descriptions that are blank

lowerbound = 0
while string.find('\n',lowerbound) != -1:
	split_list = []
	while string[lowerbound] != '\n':
		if string[lowerbound] == '"':
			lowerbound += 1 #Remove quote from beginning
			splitter = '"' 
		else:
			splitter = ',' 
		upperbound = string.find(splitter, lowerbound)
		#Handle double quote corner case
		while string[upperbound+1] == '"' and splitter == '"': 
			upperbound = string.find('"', upperbound + 2)


		data_piece = string[lowerbound:upperbound]
		split_list.append(strip_tags(data_piece))
		lowerbound = upperbound + 1 #Don't include the split char itself
	lowerbound += 1 #Remove /n from end of data entry

	description = split_list[86]
	if description.replace(' ','') == '':
		blank_descriptions.append({'descr': description, 'term': split_list[5], 
			'subject': split_list[39], 'school': split_list[47]})
	elif len(description.split()) <= 10:
		short_descriptions.append({'descr': description, 'term': split_list[5], 
			'subject': split_list[39], 'school': split_list[47]})
	else:
		course_descriptions.append(description)


	list_of_entries.append(split_list)
	print len(list_of_entries)
	# if len(list_of_entries) > stop_after: break

with open('course_descriptions','wb') as f:
	dump(course_descriptions, f)

with open('course_descriptions.txt','wb') as f:
	for entry in course_descriptions:
		f.write(entry+'\n')

with open('short_descriptions','wb') as f:
	dump(short_descriptions, f)

with open('short_descriptions.txt','wb') as f:
	for entry in short_descriptions:
		f.write(str(entry)+'\n')

with open('blank_descriptions','wb') as f:
	dump(blank_descriptions, f)

with open('blank_descriptions.txt','wb') as f:
	for entry in blank_descriptions:
		f.write(str(entry)+'\n')


