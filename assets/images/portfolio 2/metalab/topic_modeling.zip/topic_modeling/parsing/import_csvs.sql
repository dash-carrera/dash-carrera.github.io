DROP TABLE classes;
CREATE TABLE classes
(
course_id character varying(6),
course_offer_number numeric(38,0),
term_code character varying(4),
term_description character varying(30),
session_code character varying(3),
class_section character varying(4),
crse_cat_effective_date date,
subject character varying(8),
subject_description character varying(50),
catalog_number character varying(10),
catalog_number_int integer,
catalog_number_char character varying(80),
catalog_number_sort character varying(144),
class_number numeric(38,0),
academic_year character varying(4),
course_title_long character varying(100),
enrollment_cap numeric(38,0),
component_code character varying(3),
component_description character varying(30),
equivalent_course_id character varying(5),
academic_career character varying(4),
class_acad_org character varying(10),
class_acad_org_description character varying(50),
subject_acad_org character varying(10),
subject_acad_org_desc character varying(50),
acad_group character varying(5),
acad_group_description character varying(30),
grading_basis character varying(3),
grading_basis_description character varying(50),
class_type character varying(1),
class_type_description character varying(30),
enrollment_consent character varying(1),
enrollment_consent_description character varying(30),
requirement_group character varying(6),
requirement_group_description text,
exam_date date,
exam_time_code character varying(8),
schedule_print character varying(1),
class_status character varying(1),
class_status_description character varying(30),
term_pattern_code character varying(10),
term_pattern_description character varying(30),
course_note character varying(4000),
recommend_prep character varying(4000),
bracketed_flag character varying(1),
course_descr character varying(50),
course_descrlong character varying(4000),
enrollment_count integer,
final_exam character varying(1),
class_start_date date,
class_end_date date,
units_maximum real, 
units_minimum real,
instruction_mode character varying(1),
split_owner character varying(1)
);

COPY classes
FROM '/Users/Dash/Desktop/Berkman/Data_Dumps/sis_ods_export/ods_classes_view.csv' DELIMITER ',' CSV HEADER;

/*
DROP TABLE notes;
CREATE TABLE notes
(
crse_id character varying(6),
crse_offer_nbr numeric(38,0),
strm character varying(4),
term_descr character varying(30),
session_code character varying(3),
class_section character varying(4),
class_notes_seq numeric(38,0),
descrlong character varying(4000),
academic_career character varying(4)
);

COPY notes
FROM '/Users/Dash/Desktop/Berkman/Data_Dumps/sis_ods_export/ods_class_notes_view.csv' DELIMITER ',' CSV HEADER;

DROP TABLE meeting_patterns;
CREATE TABLE meeting_patterns
(
course_id character varying(6),
course_offer_number numeric(38,0),
term_code character varying(4),
term_description character varying(30),
session_code character varying(3),
class_section character varying(4),
class_meeting_number numeric(38,0),
class_meeting_description character varying(4000),
meeting_time_start character varying(10),
meeting_time_end character varying(10),
mon character varying(1),
tue character varying(1),
wed character varying(1),
thurs character varying(1),
fri character varying(1),
sat character varying(1),
sun character varying(1),
start_date date,
end_date date,
facility_id character varying(10),
facility_description character varying(30),
academic_career character varying(4)
);

COPY meeting_patterns
FROM '/Users/Dash/Desktop/Berkman/Data_Dumps/sis_ods_export/ods_class_mtg_patterns_view.csv' DELIMITER ',' CSV HEADER;

DROP TABLE instructors;
CREATE TABLE instructors
(
course_id character varying(6),
course_offer_number numeric(38,0),
term_code character varying(4),
term_description character varying(30),
session_code character varying(2),
class_section character varying(4),
class_meeting_number numeric(38,0),
instructor_sequence numeric(38,0),
instructor_id character varying(50),
instructor_role character varying(4),
instructor_role_description character varying(30),
instructor_name character varying(50),
academic_career character varying(4),
bracketed_flag character varying(1)
);

COPY instructors
FROM '/Users/Dash/Desktop/Berkman/Data_Dumps/sis_ods_export/ods_class_instructors_view_very_secure.csv' DELIMETER ',' CSV HEADER;*/
